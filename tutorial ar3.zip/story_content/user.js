function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6o6zTuQ7Bd7":
        Script1();
        break;
      case "6cv42Xu4yKV":
        Script2();
        break;
      case "5kMeTR2MmJJ":
        Script3();
        break;
      case "6fRSgpudi1K":
        Script4();
        break;
      case "5k97026GLDf":
        Script5();
        break;
      case "69lPRxEm4hJ":
        Script6();
        break;
      case "5ZyGG26ZLmv":
        Script7();
        break;
  }
}

function Script1()
{
  var audio= document.getElementById('bgSong');
audio.src="musik.mp3";
audio.load();
audio.play();
}

function Script2()
{
  var audio = document.getElementById('bgSong');
audio.volume =0.0;
}

function Script3()
{
  var audio = document.getElementById('bgSong');
audio.volume =0.1;
}

function Script4()
{
  var audio = document.getElementById('bgSong');
audio.volume =0.2;
}

function Script5()
{
  var audio = document.getElementById('bgSong');
audio.volume =0.3;
}

function Script6()
{
  var audio = document.getElementById('bgSong');
audio.volume =0.4;
}

function Script7()
{
  var audio = document.getElementById('bgSong');
audio.volume =0.5;
}

